# QA Notes — ROSTAM UNIT 1.4.1-dev

## Passed
- Server TypeScript source transpilation syntax check: 0 diagnostics.
- Client TSX source transpilation syntax check: 0 diagnostics.
- SQLite schema execution in an in-memory database.
- National currency profile seeding and uniqueness constraint check.
- Exchange-rate update formula remains within the configured 0.25–3.5 CR range.
- Player territory map UI wired to the existing validated `/api/territories` endpoint.
- Ceasefire endpoint now restores contested player-drawn polygons to their original nation.

## Not yet verified
- `npm install` timed out in this environment; dependencies were not installed.
- Full `tsc -b`, Vite production build and server build were not run.
- No live HTTP, SQLite file migration, browser interaction or WebSocket integration test was run.
- No APK/AAB generated.
- No public hosting, real Android device or multiplayer load test completed.

## Known scope
- AI nations are server-side rule-based agents, not an externally hosted generative AI.
- Currency rates are a game simulation, not real-world financial exchange rates.
- Battles remain abstract; ceasefire restores player-drawn territory polygons to their original nation.

## 1.4.2-dev — additional checks
- TypeScript transpile syntax check: server `index.ts` — passed (no syntax diagnostics).
- TypeScript/JSX transpile syntax check: client `App.tsx` — passed (no syntax diagnostics).
- Added schema for ten government seats per nation, government operation history, and the defense multiplier migration.
- Added server routes for cabinet read, abstract operation resolution, and replacement appointment.
- Added client government tab with cabinet display, vacant-seat appointment, target/role/budget selection, and operation history.
- Defensive battle calculation now applies the defending nation's `defense_modifier`; removing the defense minister lowers it to 72% of prior value (minimum 55%).
- Full dependency installation/build and live HTTP/database integration tests remain pending: `npm install` did not finish within the available execution window. No APK was built.


## 1.4.3-web checks added
- TypeScript/TSX transpile syntax check: passed for server and client sources.
- Production hosting path: Express serves `client/dist` from a path resolved relative to the server module, so it works when launched from the server workspace.
- `/health` endpoint added for hosting health checks.
- WebSocket client now derives `wss://` from the deployed HTTPS origin; localhost development still uses port 2567.
- Cabinet proposal table, generation, player accept/reject endpoint and UI added.
- Full npm dependency install, Vite production build, server type-check, live HTTP/WebSocket integration and real-device tests remain pending.

## 1.4.3-web packaging review (2026-11-26)
- PASS: archive extracted successfully; ZIP integrity test reports no compressed-data errors.
- PASS: TypeScript transpile syntax checks completed with zero diagnostics for `server/src/index.ts`, `client/src/App.tsx`, and `client/src/main.tsx`.
- PASS: JSON parsing for root/server/client package manifests, TypeScript configs, and PWA manifest.
- NOT COMPLETED: dependency installation timed out in the build environment. Full `npm run build`, runtime API checks, WebSocket multiplayer tests, deployment and real-device tests remain outstanding.
- STATUS: source package is prepared for repository upload; no public deployment URL exists yet.
