# ROSTAM UNIT — multiplayer geopolitical strategy prototype

ROSTAM UNIT is a Persian/English React + TypeScript + Vite client with an Express + SQLite + Colyseus WebSocket server. The primary release target is a browser game: players open one HTTPS link on Android, iPhone, tablet or desktop. No extra app is required. This is still a prototype and is not yet deployed or production-certified.

## Included systems in this source snapshot

- Responsive glass-style command center and interactive world map.
- Account registration/login using bcrypt and JWT; persistent nation selection.
- Nation economy: treasury, tax, food, minerals, factories, farms, mines and oil wells.
- Finite strategic oil reserves, world oil market, automatic imports when affordable, energy shortages and industrial/stability penalties.
- Iran-only Hormuz controls and in-game transit tolls.
- National currencies for all seeded nations, unique currency codes, editable currency name/code, and simulated exchange rates tied gradually to stability and treasury. These are fictional game values, not real financial rates.
- Player-drawn territory polygons on the world map, server-side polygon validation and persistence. Ceasefire restores contested drawn territories to their original nation.
- Player-created sanctions with game effects on trade, finance, oil, recruitment and diplomacy.
- Autonomous rule-based AI nations with economic, diplomatic and limited military decisions. This is not a hosted LLM.
- Player diplomacy, wars, ceasefire, basic battle resolution, global events and authenticated room chat.
- Fictional political influence/security mechanics, kept abstract and non-operational.
- Cabinet advisors create role-based policy proposals; the player can accept or reject them. NPC cabinets make automatic decisions.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
cp .env.example server/.env
# Set JWT_SECRET to a unique random value with at least 32 characters.
npm run dev
```

Open `http://localhost:5173`. The API and WebSocket server use port `2567`. Set `VITE_API_URL` and `VITE_SERVER_URL` at client build time when deploying to separate hosts.

## Build and release status

This archive contains source code and project configuration, not a hosted game link. A live URL still requires deployment to a hosting provider; this workspace cannot publish to an account without its credentials.

## Deploy as one website (Render example)

1. Push this folder to a Git repository.
2. Create a Render Web Service from that repository and use the included `render.yaml` blueprint (or set the same build/start commands manually).
3. Attach persistent disk storage at `/var/data`; set `DB_PATH=/var/data/rostam.sqlite` and a strong `JWT_SECRET` (32+ random characters). Keep WebSockets enabled and use the service's HTTPS URL.
4. Once deployed, share that HTTPS link with friends. They do not need to install an app.

The service health endpoint is `/health`. SQLite must live on persistent storage or player accounts and world state may be lost when the host replaces the instance. For a larger public launch, migrate to managed PostgreSQL and add backups, monitoring and load testing.

The full production build and device tests have not yet run in this environment because dependency installation previously timed out. No APK/AAB is included; APK packaging is optional and secondary to the browser game.

### Government and web release (1.4.3-web)
Every nation receives a ten-seat cabinet. The government tab displays official skill, loyalty, and status. Vacant roles can be refilled for an in-game treasury cost. Abstract fictional political operations can target a cabinet role in another playable nation; results are calculated from game stats only. If the defense minister is removed, the country's defensive multiplier falls and is applied when resolving battles. Appointing a replacement restores part of that multiplier. This is a fictional game mechanic and does not model real-world methods.

- One-origin deployment: built client is served by Express alongside `/api`, `/health` and Colyseus WebSocket traffic.
- Browser WebSocket address is derived from the current site, using `wss://` on HTTPS. Local development still connects to port 2567.
- Cabinet advisors generate policy proposals for player nations; decisions apply in-game economic, food or defense effects. NPC cabinets auto-resolve their recommendations.
