# ROSTAM UNIT — Changelog

## 1.4.1-dev — Currency, player borders and peace settlement

- Added persistent national currency profiles for every seeded nation, with unique currency codes.
- Added a server API to view all exchange rates and rename a nation's currency after validation and a 400 CR treasury fee.
- Added a gradual exchange-rate simulation: currency strength responds to national stability and treasury fundamentals, with bounded rates to prevent runaway values.
- Added a glass-style currency panel to the economy screen, including the player's currency and a world exchange-rate list.
- Added player-drawn territory polygons to the interactive world map: click to place points, undo the last point, name the territory and save it to the server.
- Rendered saved player polygons for all players and hid default country boundary strokes on the map so player-drawn borders stand out.
- Updated ceasefire handling so contested player-drawn territories return to their original nation when the war ends in peace.
- Kept the existing oil market, finite reserves, automatic oil imports/shortages, Hormuz controls, sanctions and autonomous NPC systems intact.

## Verification in this editing session

- TypeScript/TSX transpilation syntax checks: 0 syntax diagnostics for server and client files.
- SQLite in-memory checks: currency table creation, initial seeding, unique currency-code constraint and bounded exchange-rate update passed.
- Full dependency install and production build were not completed: `npm install` exceeded the available execution window.
- APK packaging, hosted server deployment, WebSocket multiplayer load tests and real-device tests remain outstanding.

## 1.4.2-dev — Government & command continuity
- Added a ten-seat cabinet for every nation: leader, president, defense, economy, foreign affairs, intelligence, interior, energy, industry, and special forces.
- Added a government screen showing each official's skill, loyalty, and active/vacant status.
- Added abstract, fictional stat-based political operations against cabinet seats, with budget limits, security/loyalty modifiers, exposure, and containment outcomes. No real-world methods are represented.
- Removing the defense minister lowers the nation's defense multiplier to 72% of its previous value (minimum 55%), directly affecting defensive war calculations.
- Added paid appointment of replacements; appointing a defense minister restores part of the lost defense modifier, up to 100%.
- Added government operation history and world event feed entries.

## 1.4.3-web — Browser-first multiplayer release path
- Made the browser website the primary release target: Express now serves the built Vite client, API and Colyseus WebSocket traffic from one origin.
- Added a health-check endpoint for deployment platforms and resolved the client build directory relative to the server module.
- Updated multiplayer connection setup to use the current website host and secure `wss://` automatically on HTTPS; local development continues to use port 2567.
- Added a Render deployment blueprint with persistent SQLite disk configuration and generated JWT secret.
- Added cabinet advisor proposals for food security, defense readiness, industry and tax policy. Players can accept or reject proposals; NPC cabinets resolve their proposals using skill and loyalty.
- Fixed profile refresh so an account without a selected country does not fail when loading government data.

### Verification
- Server and client TypeScript/TSX transpile syntax checks passed.
- SQLite schema and government-proposal smoke test passed.
- ZIP integrity test passed.
- Full npm install/build, deployed HTTP/WebSocket test and Android/browser device testing remain pending.
