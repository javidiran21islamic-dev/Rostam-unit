import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:2567',
        changeOrigin: true,
      },
      '/health': {
        target: 'http://127.0.0.1:2567',
        changeOrigin: true,
      },
    },
  },
});
